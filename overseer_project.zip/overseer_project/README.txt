Overseer Project

How to run:
1. Install dependencies from requirements.txt
2. Run `python overseer_main.py`